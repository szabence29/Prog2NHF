#ifndef NHF___PROG2_KEZI_H
#define NHF___PROG2_KEZI_H

#include "iostream"
#include "csapat.h"
#include "memtrace.h"
#include <fstream>
#include <sstream>

///Kezi osztály, amely a Csapat osztály leszármazottja
///Tőle örököl adattagokat, például csapatnév, vagy létszám
class Kezi: public Csapat{
    ///Külön adattag, amely csak a Kezi osztálynak van meg.
    int tamogatas;
public:
    ///Konstuktor
    Kezi(char s = 'H', std::string n = "", int sz = 0, std::string l = "", std::string e = "", int h = 0, int t = 0):
    Csapat(s, std::move(n), sz, std::move(l), std::move(e), h), tamogatas(t) {}

    ///kiir függvény amely kiírja a kezi osztály adattagjait.
    void kiir(std::ostream& os);

    ///get függvény, amelynek a kiírásnál fontos szerepe van
    int getTamogatas() const;

    ///set függvény, amelynek a szerkesztésnél fontos szerepe van.
    void setTamogatas(int t);

    ///Destruktor
    ~Kezi(){}
};
///Output stream kezelő operátor túlterhelése.
std::ostream& operator<<(std::ostream& os, const Kezi& k);

#endif //NHF___PROG2_KEZI_H
