#ifndef NHF___PROG2_TEST_H
#define NHF___PROG2_TEST_H

void test();
void test2();

#endif //NHF___PROG2_TEST_H
