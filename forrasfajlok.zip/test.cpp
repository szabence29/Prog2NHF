#include "test.h"
#include "foci.h"
#include "kezi.h"
#include "kosar.h"
#include "fajlkezeles.h"
#include "Lista.hpp"
#include <iostream>
#include "gtest_lite.h"

void test(){
    ///Focicsapat tesztje

    Foci f('F', "Manchester United", 20, "Premier league", "Erik Ten Hag", 3, "Sir Alex Fergusson");

    TEST(foci, sportag){
        EXPECT_EQ('F', f.getSportag()) << "Nem jo a sportag";
        EXPECT_EQ('B', f.getSportag()) << "Nem jo a sportag";
    }ENDM

    TEST(foci, nev){
        EXPECT_EQ("Manchester United", f.getCsapatnev()) << "Nem jo a nev";
        EXPECT_EQ("Manchester Unite", f.getCsapatnev()) << "Nem jo a nev";
    }ENDM

    TEST(foci, letszam){
        EXPECT_EQ(20, f.getLetszam()) << "Nem jo a letszam";
        EXPECT_EQ(21, f.getLetszam()) << "Nem jo a letszam";
    }ENDM

    TEST(foci, liga){
        EXPECT_EQ("Premier league", f.getLiga()) << "Nem jo a liga";
        EXPECT_EQ("Premier leagu", f.getLiga()) << "Nem jo a liga";
    }ENDM

    TEST(foci, edzo){
        EXPECT_EQ("Erik Ten Hag", f.getEdzo()) << "Nem jo az edzo";
        EXPECT_EQ("Erik Ten Ha", f.getEdzo()) << "Nem jo az edzo";
    }ENDM

    TEST(foci, helyezes){
        EXPECT_EQ(3, f.getHelyezes()) << "Nem jo a helyezes";
        EXPECT_EQ(4, f.getHelyezes()) << "Nem jo a helyezes";
    }ENDM

    TEST(foci, masodedzo){
        EXPECT_EQ("Sir Alex Fergusson", f.getEdzo2())  << "Nem jo a masodedzo";
        EXPECT_EQ("Sir Alex Fergusso", f.getEdzo2())  << "Nem jo a masodedzo";
    }ENDM

    ///Kezicsapat tesztje

    Kosar k('B', "Lakers", 20, "NBA", "Darvin Ham", 1, 10);

    TEST(kezi, sportag){
            EXPECT_EQ('B', k.getSportag()) << "Nem jo a sportag";
            EXPECT_EQ('H', k.getSportag()) << "Nem jo a sportag";
        }ENDM

    TEST(kezi, nev){
            EXPECT_EQ("Lakers", k.getCsapatnev()) << "Nem jo a nev";
            EXPECT_EQ("V", k.getCsapatnev()) << "Nem jo a nev";
        }ENDM

    TEST(kezi, letszam){
            EXPECT_EQ(20, k.getLetszam()) << "Nem jo a letszam";
            EXPECT_EQ(21, k.getLetszam()) << "Nem jo a letszam";
        }ENDM

    TEST(kezi, liga){
            EXPECT_EQ("NBA", k.getLiga()) << "Nem jo a liga";
            EXPECT_EQ("NBB", k.getLiga()) << "Nem jo a liga";
        }ENDM

    TEST(kezi, edzo){
            EXPECT_EQ("Darvin Ham", k.getEdzo()) << "Nem jo az edzo";
            EXPECT_EQ("d", k.getEdzo()) << "Nem jo az edzo";
        }ENDM

    TEST(kezi, helyezes){
            EXPECT_EQ(1, k.getHelyezes()) << "Nem jo a helyezes";
            EXPECT_EQ(4, k.getHelyezes()) << "Nem jo a helyezes";
        }ENDM

    TEST(kezi, tamogatas){
            EXPECT_EQ(10, k.getPompom())  << "Nem jo a pompom letszam";
            EXPECT_EQ(51, k.getPompom())  << "Nem jo a pompom letszam";
        }ENDM

    ///Kosarcsapat tesztje

    Kezi b('H', "Veszprém", 20, "NBI", "Momiir Ilic", 2, 50);

    TEST(kezi, sportag){
            EXPECT_EQ('H', b.getSportag()) << "Nem jo a sportag";
            EXPECT_EQ('B', b.getSportag()) << "Nem jo a sportag";
        }ENDM

    TEST(kezi, nev){
            EXPECT_EQ("Veszprém", b.getCsapatnev()) << "Nem jo a nev";
            EXPECT_EQ("V", b.getCsapatnev()) << "Nem jo a nev";
        }ENDM

    TEST(kezi, letszam){
            EXPECT_EQ(20, b.getLetszam()) << "Nem jo a letszam";
            EXPECT_EQ(21, b.getLetszam()) << "Nem jo a letszam";
        }ENDM

    TEST(kezi, liga){
            EXPECT_EQ("NBI", b.getLiga()) << "Nem jo a liga";
            EXPECT_EQ("NBII", b.getLiga()) << "Nem jo a liga";
        }ENDM

    TEST(kezi, edzo){
            EXPECT_EQ("Momiir Ilic", b.getEdzo()) << "Nem jo az edzo";
            EXPECT_EQ("Momiir Ili", b.getEdzo()) << "Nem jo az edzo";
        }ENDM

    TEST(kezi, helyezes){
            EXPECT_EQ(2, b.getHelyezes()) << "Nem jo a helyezes";
            EXPECT_EQ(4, b.getHelyezes()) << "Nem jo a helyezes";
        }ENDM

    TEST(kezi, tamogatas){
            EXPECT_EQ(50, b.getTamogatas())  << "Nem jo a tamogatas";
            EXPECT_EQ(51, b.getTamogatas())  << "Nem jo a tamogatas";
        }ENDM
}

void test2() {
    Adatok adatok;
    Adatok adatok1;
    const std::string fajlnev = "Test.txt";
    adatok.beolvas(fajlnev);

    TEST(csapat, beolvas)
        {
            for (CsapatLista::Iterator it = adatok.getCsapatLista().begin();
                 it != adatok.getCsapatLista().end(); ++it) {
                EXPECT_EQ('F', it->getSportag()) << "Nem jo a beolvasas";
                EXPECT_EQ("Xavi", it->getEdzo()) << "Nem jo a beolvasas";
                EXPECT_EQ(1, it->getHelyezes()) << "Nem jo a beolvasas";
            }
        }
    }
}