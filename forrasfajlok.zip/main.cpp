#include "gtest_lite.h"
#include "iostream"
#include "menu.h"
#include "fajlkezeles.h"
#include "memtrace.h"

int main() {

    #ifdef CPORTA
    test();
    test2();
    #endif

    #ifndef CPORTA
    Adatok lista;
    int menupont, fajlmegnyit = 0;
    elvalaszto();
    std::cout <<"Üdvözlöm a csapatok nyilvántartásában! \n"
                "Válasszon az alábbi menü opciók közül: \n";
    alapmenupontok();
    elvalaszto();
    std::cout << "Választott menüpont: ";
    std::cin >> menupont;
    while (menupont != 4){
        switch (menupont){
            case 1:
                try{
                    fajl_megnyit_beolvas(lista);
                } catch (const char* hiba){
                    std::cout << "Hiba: " << hiba << std::endl;
                    return 0;
                }
                menukiir();
                std::cin >> menupont;
                fajlmegnyit++;
                break;
            case 2:
                if (fajlmegnyit == 0){
                    std::cout << "Nem nyitott még meg fájlt.\n";
                    menukiir();
                    std::cin >> menupont;
                    break;
                }
                szerkesztesmenu(lista);
                menukiir();
                std::cin >> menupont;
            case 3:
                if (fajlmegnyit == 0){
                    std::cout << "Nem nyitott még meg fájlt.";
                    menukiir();
                    std::cin >> menupont;
                    break;
                }
                listamenu(lista);
                menukiir();
                std::cin >> menupont;
                break;
            default:
                std::cout << "Hibás menüpontot adott meg, próbálja újra." << std::endl;
                elvalaszto();
                alapmenupontok();
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                std::cout << "\n";
                break;
        }
    }
    try {
        fajl_megnyit_kiir(lista);
    } catch (const char* hiba) {
        std::cout << "Hiba: " << hiba << std::endl;
    }
    #endif
}