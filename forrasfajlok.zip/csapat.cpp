#include "csapat.h"

///OUTPUT STREAM KEZELŐ OPERÁTOR DEFINIÁLÁSA
std::ostream& operator<<(std::ostream &os, const Csapat& cs){
    return os << "Csapatnev: " << cs.getCsapatnev() << "\n"
                << "Letszam: " << cs.getLetszam() << "\n"
                << "Edző: " << cs.getEdzo() << "\n"
                << "Liga: " << cs.getLiga() << "\n"
                << "Helyezés: " << cs.getHelyezes() <<"\n";
}

void Csapat::kiir(std::ostream &os) {
    os << (*this) << std::endl;
}

///GET FÜGGVÉNYEK DEFINIÁLÁSA

char Csapat::getSportag() const {return sportag;}
std::string Csapat::getCsapatnev() const {return csapatnev;}
int Csapat::getLetszam() const {return letszam;}
std::string Csapat::getEdzo() const {return edzo;}
std::string Csapat::getLiga() const {return liga;}
int Csapat::getHelyezes() const {return helyezes;}

///SET FÜGGVÉNYEK DEFINIÁLÁSA:

void Csapat::setCsapatnev(std::string n) {csapatnev = std::move(n);}
void Csapat::setSportag(char s) {sportag = s;}
void Csapat::setLetszam(int l) {letszam = l;}
void Csapat::setEdzo(std::string e) {edzo = std::move(e);}
void Csapat::setLiga(std::string l) {liga = std::move(l);}
void Csapat::setHelyezes(int h) {helyezes = h;}