#ifndef NHF___PROG2_MENU_H
#define NHF___PROG2_MENU_H

#include "fajlkezeles.h"
#include "string"

///menükezelő függvények
void alapmenupontok();
void menukiir();
void elvalaszto();
void fajl_megnyit_beolvas(Adatok& l);
void fajl_megnyit_kiir(Adatok& l);
void szerkesztesmenu(Adatok& l);
void listamenu(Adatok& l);

#endif //NHF___PROG2_MENU_H
