#ifndef NHF___PROG2_FOCI_H
#define NHF___PROG2_FOCI_H

#include "iostream"
#include "csapat.h"
#include "memtrace.h"
#include <fstream>
#include <sstream>


///Foci osztály, amely a Csapat osztály leszármazottja
///Tőle örököl adattagokat, például csapatnév, vagy létszám
class Foci: public Csapat {
    ///Külön adattag, amely csak a Foci osztálynak van meg.
    std::string edzo2;
public:
    ///Konstruktor
    Foci(char s = 'F', std::string n = "", int sz = 0, std::string l = "", std::string e = "", int h = 0, std::string e2 = ""):
    Csapat(s, std::move(n), sz, std::move(l), std::move(e), h), edzo2(std::move(e2)) {};

    ///kiir függvény, amely kiírja a foci osztály adattagjait
    void kiir(std::ostream& os);

    ///get függvény, amelynek a kiírásnál fontos szerepe van
    std::string getEdzo2() const;

    ///set függvény, amelynek a szerkesztésnél fontos szerepe van.
    void setEdzo2(std::string e);

    ///Destruktor
    ~Foci(){}
};

///Output stream kezelő operátor túlterhelése.
std::ostream& operator<<(std::ostream& os, const Foci& f);

#endif //NHF___PROG2_FOCI_H
