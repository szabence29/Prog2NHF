#ifndef NHF___PROG2_CSAPAT_H
#define NHF___PROG2_CSAPAT_H

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "memtrace.h"

///Csapat osztály
///A Foci, a Kezi és a Kosar osztály tőle örököl attribútumokat.

class Csapat{
    char sportag;
    std::string csapatnev;
    int letszam;
    std::string edzo;
    std::string liga;
    int helyezes;
public:
    ///Konstruktor
    Csapat(char s, std::string n = "", int sz = 1, std::string l = "", std::string e = "", int h = 0):
    sportag(s), csapatnev(std::move(n)), letszam(sz), liga(std::move(l)), edzo(std::move(e)), helyezes(h) {};

    ///kiir függvény
    ///A virtual kulcsszó azért kell, mert a leszármazott osztályok más-más adatokat írhatnak ki.
    virtual void kiir(std::ostream& os = std::cout);

    ///get függvények
    ///Visszaadják az osztályok alapvető attribútumait.
    ///A kiírásnál fontos szerepe van.
    char getSportag() const;
    std::string getCsapatnev() const;
    int getLetszam() const;
    std::string getEdzo() const;
    std::string getLiga() const;
    int getHelyezes() const;

    ///set függvény
    ///Be lehet állítani az osztályok adattagjait
    ///A szerkesztésnél fontos szerepe van.
    void setSportag(char s);
    void setCsapatnev(std::string n);
    void setLetszam(int l);
    void setEdzo(std::string e);
    void setLiga(std::string l);
    void setHelyezes(int h);

    ///Destruktor
    virtual ~Csapat(){}
};

///Output stream kezelő operátor túlterhelése.
///Ez a függvény arra szolgál, hogy kiírjon adatokat egy 'Csapat' objektumból egy kimeneti adatfolyamba.
std::ostream& operator<<(std::ostream& os, const Csapat& cs);

#endif //NHF___PROG2_CSAPAT_H
