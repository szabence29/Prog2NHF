#include "fajlkezeles.h"

///Fájlból olvas be.
///A függvény paramétere egy fájlnév, amely string típsú.
///A felhasználó egy tetszőleges fájlt megadhat, amely .txt-vel végződik.

///A beolvasás során a a függvény sorokra bontja a fájlt.
///Az adatokat az elválasztókarakter mentén eltárolja egy változóban.
///Ezeket a set függvények segítségével a megfelelő helyre rakja.
void Adatok::beolvas(const std::string& fajlnev) {
    std::ifstream file(fajlnev);
    if (!file) {
        throw std::runtime_error("Hiba: A fajl nem talalhato vagy nem nyithato meg.");
    }
    std::string sor;

    while (std::getline(file, sor)){
        std::istringstream ss(sor);
        char sportag;
        std::string csapatnev, edzo, liga, edzo2;
        int letszam, helyezes, tamogatas, pompom;
        Csapat* csapat;

        ss >> sportag;
        ss.ignore();
        std::getline(ss, csapatnev, '/');
        ss >> letszam;
        ss.ignore();
        std::getline(ss, liga, '/');
        std::getline(ss, edzo, '/');
        ss >> helyezes;
        ss.ignore();

        if (sportag == 'F'){
            std::getline(ss, edzo2, '/');
            csapat = new Foci(sportag, csapatnev, letszam, liga, edzo, helyezes, edzo2);
            hozzaadCsapat(csapat);
        } else if (sportag == 'H'){
            ss >> tamogatas;
            csapat = new Kezi(sportag, csapatnev, letszam, liga, edzo, helyezes, tamogatas);
            hozzaadCsapat(csapat);
        } else if (sportag == 'B'){
            ss >> pompom;
            csapat = new Kosar(sportag, csapatnev, letszam, liga, edzo, helyezes, pompom);
            hozzaadCsapat(csapat);
        } else {
            throw "Hibás csapatazonosító.";
        }
    }
    file.close();
}

///Egy 'Csapat' objektumot ad hozzá a csapatLista osztályhoz.
void Adatok::hozzaadCsapat(Csapat *csapat) {
    csapatLista.hozzaad(csapat);
}

///Egy meglévő csapat törlését végzi el a 'csapatLista' listából.
///Bekéri a felhasználótól a törlendő csapat nevét, majd az Iterátor segítségével végigmegy a listán
///Ha megtalálta azt a csapatot amelyet a felhasználó törölni szeretne, akkor a torolElem segítségével kitörli azt a listából.
void Adatok::torolCsapat() {
    std::string nev;
    std::cout << "Adja meg a törlendő csapat nevét: ";
    std::getline(std::cin, nev);
    for (CsapatLista::Iterator it = csapatLista.begin(); it != csapatLista.end(); ++it){
        if(it->getCsapatnev() == nev){
            try {
                csapatLista.eltavolit(it);
            } catch (const char* hiba) {
                std::cout << "Hiba: " << hiba << std::endl;
            }
            return;
        }
    }
}

///Kiírja a csapatLista elemeit a konzolra.
void Adatok::kiir() {
    for (CsapatLista::Iterator it=csapatLista.begin(); it!=csapatLista.end(); ++it) {
        it->kiir();
        std::cout << "\n";
    }
}

///Szinte olyan mint a beolvas() függvény.
///Az adatokat a program manuálisan kéri be a felhasználótól.
///Ezeket eltárolja változókban, majd a set függvények segítségével a megfelelő helyre rakja.
void Adatok::hozzaadCsapatmanualis() {
    std::string nev, edzo, liga, masodedzo;
    int letszam, helyezes, tamogatas, pompom;
    char sportag;

    Csapat* ujcsapat;


    std::cout << "Adja meg a csapat sportágát: ";
    std::cin >> sportag;
    if (sportag != 'F' or sportag != 'B' or sportag != 'H'){
        throw "Hibás csapatazonosító.";
    }
    std::cin.ignore();
    std::cout << "Adja meg a csapat nevét: ";
    std::getline(std::cin, nev);
    std::cout << "Adja meg a csapat létszámát: ";
    std::cin >> letszam;
    std::cin.ignore();
    std::cout << "Adja meg hogy a csapat melyik ligában játszik: ";
    std::getline(std::cin, liga);
    std::cout << "Adja meg a csapat edzőjét: ";
    std::getline(std::cin, edzo);
    std::cout << "Adja meg a csapat helyezését: ";
    std::cin >> helyezes;
    std::cin.ignore();
    if (sportag == 'F'){
        std::cout << "Adja meg a csapat másodedzőjét: ";
        std::getline(std::cin, masodedzo);
        ujcsapat = new Foci(sportag, nev, letszam, liga, edzo, helyezes, masodedzo);
    } else if (sportag == 'H') {
        std::cout << "Adja meg mennyi támogatást kapott a csapat: ";
        std::cin >> tamogatas;
        std::cin.ignore();
        ujcsapat = new Kezi(sportag, nev, letszam, liga, edzo, helyezes, tamogatas);
    } else if (sportag == 'B') {
        std::cout << "Adja meg a pom-pom csapat létszámát:";
        std::cin >> pompom;
        std::cin.ignore();
        ujcsapat = new Kosar(sportag, nev, letszam, liga, edzo, helyezes, pompom);
    } else {
        throw "hiba";
    }
    hozzaadCsapat(ujcsapat);
}

///Bekéri a felhasználótól a szerkeszteni kívánt csapat nevét.
///Megkeresi azt az Iterátor segítségével, majd különböző változtatásokat lehet rajta végrehajtani.
void Adatok::szerkesztCsapat() {
    std::string nev;
    int szerkszam;
    for (CsapatLista::Iterator it = csapatLista.begin(); it != csapatLista.end(); ++it) {
        std::cout << it->getCsapatnev() <<std::endl;
    }
    std::cout << "Adja meg a szerkeszteni kívánt csapat nevét: ";
    std::getline(std::cin, nev);

    for (CsapatLista::Iterator it = csapatLista.begin(); it != csapatLista.end(); ++it) {
        if (it->getCsapatnev() == nev){
            std::cout << "1 - " << it->getSportag() <<std::endl;
            std::cout << "2 - " << it->getCsapatnev() <<std::endl;
            std::cout << "3 - " << it->getLetszam() <<std::endl;
            std::cout << "4 - " << it->getLiga() <<std::endl;
            std::cout << "5 - " << it->getEdzo() <<std::endl;
            std::cout << "6 - " << it->getHelyezes() <<std::endl;
            if (it->getSportag() == 'F'){
                Foci* fociCsapat = dynamic_cast<Foci*>(it.operator->());
                if (fociCsapat) {
                    std::cout << "7 - " <<fociCsapat->getEdzo2() << std::endl;
                }
            }else if(it->getSportag() == 'H'){
                Kezi* keziCsapat = dynamic_cast<Kezi*>(it.operator->());
                if (keziCsapat) {
                    std::cout << "7 - " <<keziCsapat->getTamogatas() << std::endl;
                }
            } else {
                Kosar* kosarCsapat = dynamic_cast<Kosar*>(it.operator->());
                if (kosarCsapat){
                    std::cout << "7 - "<<kosarCsapat->getPompom() << std::endl;
                }
            }
        }
    }
    std::cout << "Adja meg a szerkeszteni kívánt elem sorszámát: ";
    std::cin >> szerkszam;
    if (szerkszam > 7)
        throw "Hibás szerkesztési szám.";
    std::cin.ignore();
    std::cout << "\n";

    for (CsapatLista::Iterator it = csapatLista.begin(); it != csapatLista.end(); ++it) {
        if (it->getCsapatnev() == nev){
            if (szerkszam == 1) {
                char ujsportag;
                std::cout << "Régi adat: " << it->getSportag() << std::endl;
                std::cout << "Adja meg az új adatot: ";
                std::cin >> ujsportag;
                if (ujsportag != 'F' or ujsportag != 'B' or ujsportag != 'H')
                    throw "Hibás csapatazonosító";
                it->setSportag(ujsportag);
                std::cout << "\n";
                std::cout << "Sikeres szerkesztés!" << std::endl;
            }
            if (szerkszam == 2) {
                std::string ujnev;
                std::cout << "Régi adat: " << it->getCsapatnev() << std::endl;
                std::cout << "Adja meg az új adatot: ";
                std::getline(std::cin, ujnev);
                it->setCsapatnev(ujnev);
                std::cout << "\n";
                std::cout << "Sikeres szerkesztés!" << std::endl;
            }
            if (szerkszam == 3) {
                std::cout << "Régi adat: " << it->getLetszam() << std::endl;
                int ujletszam;
                std::cout << "Adja meg az új adatot: ";
                std::cin >> ujletszam;
                it->setLetszam(ujletszam);
                std::cout << "\n";
                std::cout << "Sikeres szerkesztés!" << std::endl;
            }
            if (szerkszam == 4) {
                std::string ujliga;
                std::cout << "Régi adat: " << it->getLiga() << std::endl;
                std::cout << "Adja meg az új adatot: ";
                std::getline(std::cin, ujliga);
                it->setLiga(ujliga);
                std::cout << "\n";
                std::cout << "Sikeres szerkesztés!" << std::endl;
            }
            if (szerkszam == 5) {
                std::string ujedzo;
                std::cout << "Régi adat: " << it->getEdzo() << std::endl;
                std::cout << "Adja meg az új adatot: ";
                std::getline(std::cin, ujedzo);
                std::cout << "\n";
                it->setEdzo(ujedzo);
                std::cout << "Sikeres szerkesztés!" << std::endl;
            }
            if (szerkszam == 6) {
                int ujhelyezes;
                std::cout << "Régi adat: " << it->getHelyezes() << std::endl;
                std::cout << "Adja meg az új adatot: ";
                std::cin >> ujhelyezes;
                it->setHelyezes(ujhelyezes);
                std::cout << "\n";
                std::cout << "Sikeres szerkesztés!" << std::endl;
            }
            if (szerkszam == 7) {
                if (it->getSportag() == 'F') {
                    std::string ujmasodedzo;
                    Foci *fociCsapat = dynamic_cast<Foci *>(it.operator->());
                    if (fociCsapat) {
                        std::cout << "Régi adat: " << fociCsapat->getEdzo2() <<std::endl;
                        std::cout << "Adja meg az új adatot: ";
                        std::getline(std::cin, ujmasodedzo);
                        fociCsapat->setEdzo2(ujmasodedzo);
                        std::cout << "\n";
                        std::cout << "Sikeres szerkesztés!" << std::endl;
                    }
                } else if (it->getSportag() == 'K') {
                    int ujtamogatas;
                    Kezi *keziCsapat = dynamic_cast<Kezi *>(it.operator->());
                    if (keziCsapat) {
                        std::cout << "Régi adat: " << keziCsapat->getTamogatas() <<std::endl;
                        std::cout << "Adja meg az új adatot: ";
                        std::cin >> ujtamogatas;
                        keziCsapat->setTamogatas(ujtamogatas);
                        std::cout << "\n";
                        std::cout << "Sikeres szerkesztés!" << std::endl;
                    }
                } else {
                    int ujpompom;
                    Kosar *kosarCsapat = dynamic_cast<Kosar *>(it.operator->());
                    if (kosarCsapat) {
                        std::cout << "Régi adat: " << kosarCsapat->getPompom() <<std::endl;
                        std::cout << "Adja meg az új adatot: ";
                        std::cin >> ujpompom;
                        kosarCsapat->setPompom(ujpompom);
                        std::cout << "\n";
                        std::cout << "Sikeres szerkesztés!" << std::endl;
                    }
                }
            }
        }
    }
}

///A függvény paramétere egy string típusú fájlnév.
///A függvény hs nem létezik ilyen fájl, akkor készít egyet, ha pedig már van ilyen, akkor megnyitja.
///Az Iterátor segítségével bejárja a listát, majd a bemeneti minta szerint kiírja azt a fájlba.
void Adatok::fajlbakiir(const std::string &fajlnev) {
    std::ofstream file;
    file.open(fajlnev);
    if (!file) {
        file.close();
        throw "Nem sikerült megnyitni a fájlt.";
    }
    for (CsapatLista::Iterator it = csapatLista.begin(); it != csapatLista.end(); ++it) {
        file << it->getSportag() << "/";
        file << it->getCsapatnev() << "/";
        file << it->getLetszam() << "/";
        file << it->getLiga() << "/";
        file << it->getEdzo() << "/";
        file << it->getHelyezes() << "/";
        if (it->getSportag() == 'F'){
            Foci* fociCsapat = dynamic_cast<Foci*>(it.operator->());
            if (fociCsapat) {
                file << fociCsapat->getEdzo2();
            }
        }else if(it->getSportag() == 'H'){
            Kezi* keziCsapat = dynamic_cast<Kezi*>(it.operator->());
            if (keziCsapat) {
                file << keziCsapat->getTamogatas();
            }
        } else {
            Kosar* kosarCsapat = dynamic_cast<Kosar*>(it.operator->());
            if (kosarCsapat){
                file << kosarCsapat->getPompom();
            }
        }
        file << "\n";
    }
    file.close();
}

///Csak a focicsapatokat írja ki a a standard outputra.
///Az iterátor segítségével végigmegy a csapatokon, és csak azt írja ki, amelynek a sportága 'F', azaz foci.
void Adatok::csakfocicsapatkiir(){
    for (CsapatLista::Iterator it = csapatLista.begin(); it != csapatLista.end(); ++it) {
        if (it->getSportag() == 'F'){
            std::cout << "Csapatnev: " << it->getCsapatnev() <<std::endl;
            std::cout << "Letszam: " << it->getLetszam() <<std::endl;
            std::cout << "Liga: " << it->getLiga() <<std::endl;
            std::cout << "Edzo: " << it->getEdzo() <<std::endl;
            std::cout << "Helyezes: " << it->getHelyezes() <<std::endl;
            Foci* fociCsapat = dynamic_cast<Foci*>(it.operator->());
            if (fociCsapat) {
                std::cout << "Masodedzo: " << fociCsapat->getEdzo2() << std::endl;
            }
        }
    }
}

///Csak a kézicsapatokat írja ki a a standard outputra.
///Az iterátor segítségével végigmegy a csapatokon, és csak azt írja ki, amelynek a sportága 'H', azaz Kézi (Handball).
void Adatok::csakkezicsapatkiir() {
    for (CsapatLista::Iterator it = csapatLista.begin(); it != csapatLista.end(); ++it) {
        if (it->getSportag() == 'H'){
            std::cout << "Csapatnev: " << it->getCsapatnev() <<std::endl;
            std::cout << "Letszam: " << it->getLetszam() <<std::endl;
            std::cout << "Liga: " << it->getLiga() <<std::endl;
            std::cout << "Edzo: " << it->getEdzo() <<std::endl;
            std::cout << "Helyezes: " << it->getHelyezes() <<std::endl;
            Kezi* KeziCsapat = dynamic_cast<Kezi*>(it.operator->());
            if (KeziCsapat) {
                std::cout << "Tamogatas: " << KeziCsapat->getTamogatas() << std::endl;
            }
        }
    }
}

///Csak a kosárcsapatokat írja ki a a standard outputra.
///Az iterátor segítségével végigmegy a csapatokon, és csak azt írja ki, amelynek a sportága 'B', azaz Kézi (Basketball).
void Adatok::csakkosarcsapatkiir() {
    for (CsapatLista::Iterator it = csapatLista.begin(); it != csapatLista.end(); ++it) {
        if (it->getSportag() == 'B'){
            std::cout << "Csapatnev: " << it->getCsapatnev() <<std::endl;
            std::cout << "Letszam: " << it->getLetszam() <<std::endl;
            std::cout << "Liga: " << it->getLiga() <<std::endl;
            std::cout << "Edzo: " << it->getEdzo() <<std::endl;
            std::cout << "Helyezes: " << it->getHelyezes() <<std::endl;
            Kosar* KosarCsapat = dynamic_cast<Kosar*>(it.operator->());
            if (KosarCsapat) {
                std::cout << "Tamogatas: " << KosarCsapat->getPompom() << std::endl;
            }
        }
    }
}