#include "menu.h"
#include "iostream"

///A kód olvashatósága érdekében kiírja az alap menüpontokat
void menukiir(){
    elvalaszto();
    alapmenupontok();
    elvalaszto();
    std::cout << "Választott menüpont: ";
}

///alap menüpontok
void alapmenupontok(){
    std::cout <<"(1) - Fájl beolvasása\n"
                 "(2) - Szerkesztés \n"
                 "(3) - Csapatok listázása \n"
                 "(4) - Kilépés a programból.\n";
}

void elvalaszto(){
    std::cout << "==============================\n";
}

///A kód olvashatósága végett a fájl megnyitására szolgáló függvény.
///Paramétere egy Adatok típusú változó.
void fajl_megnyit_beolvas(Adatok& l){
    std::string fajlnev;
    std::cout << "Adja meg a beolvasandó fájl nevét .txt-vel a végén: ";
    std::cin.ignore();
    std::getline(std::cin, fajlnev);
    l.beolvas(fajlnev);
}

///A kód olvashatósága végett a fájlba kiírásra szolgáló függvény.
///Paramétere egy Adatok típusú változó.
void fajl_megnyit_kiir(Adatok& l){
    std::string fajlnev;
    std::cout << "Adja meg a fájl nevét, amibe az adatokat kiírja: ";
    std::cin.ignore();
    std::getline(std::cin, fajlnev);
    l.fajlbakiir(fajlnev);
}

///A kód olvashatósága végett ez egy almenü.
///Itt vannak benne a szerkesztési menüpontok, és a függvények.
///Paramétere egy Adatok típusú változó.
///Ezel a felhasználó navigál a szerkesztési menüpontok között, és műveleteket hajt végre.
void szerkesztesmenu(Adatok& l){
    int menupont;
    elvalaszto();
    std::cout << "(1) - Csapat hozzáadása\n"
                 "(2) - Csapat törlése\n"
                 "(3) - Csapat szerkesztése\n"
                 "(4) - visszalépés a menübe\n";
    elvalaszto();
    std::cout << "Választott menüpont: ";
    std::cin >> menupont;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); /// Törli a bemeneti puffert

    while (menupont != 4){
        switch (menupont) {
            case 1:
                try{
                    l.hozzaadCsapatmanualis();
                } catch (const char* hiba) {
                    std::cout << "Hiba: " << hiba << std::endl;
                }
                elvalaszto();
                std::cout << "(1) - Csapat hozzáadása\n"
                             "(2) - Csapat törlése\n"
                             "(3) - Csapat szerkesztése\n"
                             "(4) - visszalépés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); /// Törli a bemeneti puffert
                break;
            case 2:
                try {
                    l.torolCsapat();
                } catch (const char* hiba) {
                    std::cout << "Hiba: " << hiba << std::endl;
                }
                elvalaszto();
                std::cout << "(1) - Csapat hozzáadása\n"
                             "(2) - Csapat törlése\n"
                             "(3) - Csapat szerkesztése\n"
                             "(4) - visszalépés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); /// Törli a bemeneti puffert
                break;
            case 3:
                try{
                    l.szerkesztCsapat();
                } catch (const char* hiba){
                    std::cout << "Hiba: " << hiba << std::endl;
                }
                elvalaszto();
                std::cout << "(1) - Csapat hozzáadása\n"
                             "(2) - Csapat törlése\n"
                             "(3) - Csapat szerkesztése\n"
                             "(4) - visszalépés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); /// Törli a bemeneti puffert
                break;
            default:
                std::cout << "Hibás menüpontot adott meg, próbálja újra.\n";
                elvalaszto();
                std::cout << "(1) - Csapat hozzáadása\n"
                             "(2) - Csapat törlése\n"
                             "(3) - Csapat szerkesztése\n"
                             "(4) - visszalépés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); /// Törli a bemeneti puffert
                break;
        }
    }
}

///A kód olvashatósága végett ez egy almenü.
///Itt vannak benne a listázási menüpontok, és a függvények.
///Paramétere egy Adatok típusú változó.
///Ezel a felhasználó navigál a listázási menüpontok között, és műveleteket hajt végre.
void listamenu(Adatok& l){
    int menupont;
    elvalaszto();
    std::cout << "(1) - Minden csapat listázása\n"
                 "(2) - Focicsapat rangsorok\n"
                 "(3) - Kézicsapat rangsorok\n"
                 "(4) - Kosárlabda rangsorok\n"
                 "(5) - Visszalpés a menübe\n";
    elvalaszto();
    std::cout << "Választott menüpont: ";
    std::cin >> menupont;
    std::cout << "\n";
    while (menupont != 5){
        switch (menupont) {
            case 1:
                l.kiir();
                elvalaszto();
                std::cout << "(1) - Minden csapat listázása\n"
                             "(2) - Focicsapat rangsorok\n"
                             "(3) - Kézicsapat rangsorok\n"
                             "(4) - Kosárlabda rangsorok\n"
                             "(5) - Visszalpés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                break;
            case 2:
                l.csakfocicsapatkiir();
                elvalaszto();
                std::cout << "(1) - Minden csapat listázása\n"
                             "(2) - Focicsapat rangsorok\n"
                             "(3) - Kézicsapat rangsorok\n"
                             "(4) - Kosárlabda rangsorok\n"
                             "(5) - Visszalpés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                break;
            case 3:
                l.csakkezicsapatkiir();
                elvalaszto();
                std::cout << "(1) - Minden csapat listázása\n"
                             "(2) - Focicsapat rangsorok\n"
                             "(3) - Kézicsapat rangsorok\n"
                             "(4) - Kosárlabda rangsorok\n"
                             "(5) - Visszalpés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                break;
            case 4:
                l.csakkosarcsapatkiir();
                elvalaszto();
                std::cout << "(1) - Minden csapat listázása\n"
                             "(2) - Focicsapat rangsorok\n"
                             "(3) - Kézicsapat rangsorok\n"
                             "(4) - Kosárlabda rangsorok\n"
                             "(5) - Visszalpés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                break;
            default:
                std::cout << "Hibás menüpontot adott meg, próbálja újra.\n";
                elvalaszto();
                std::cout << "(1) - Minden csapat listázása\n"
                             "(2) - Focicsapat rangsorok\n"
                             "(3) - Kézicsapat rangsorok\n"
                             "(4) - Kosárlabda rangsorok\n"
                             "(5) - Visszalpés a menübe\n";
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                break;
        }
    }
}

