#include "kezi.h"

///OTPUT STREAM OPERÁTOR DEFINIÁLÁSA
std::ostream& operator<<(std::ostream& os, const Kezi& k){
    return os << (Csapat&)k << "Tamogatas: " << k.getTamogatas();
}

void Kezi::kiir(std::ostream &os) {
    os << *this << std::endl;
}

///GET FÜGGVÉNY DEFINIÁLÁSA

int Kezi::getTamogatas() const {return tamogatas;}

///SET FÜGGVÉNY DEFINIÁLÁSA

void Kezi::setTamogatas(int t) {tamogatas = t;}