#ifndef NHF___PROG2_KOSAR_H
#define NHF___PROG2_KOSAR_H

#include "iostream"
#include "csapat.h"
#include "memtrace.h"
#include <fstream>
#include <sstream>

///Kosar osztály, amely a Csapat osztály leszármazottja
///Tőle örököl adattagokat, például csapatnév, vagy létszám
class Kosar: public Csapat {
    ///Külön adattag, amely csak a Kosar osztálynak van meg.
    int pompom;
public:
    ///Konstruktor
    Kosar(char s = 'B', std::string n = "", int sz = 0, std::string l = "", std::string e = "", int h = 0, int p = 0):
    Csapat(s, std::move(n), sz, std::move(l), std::move(e), h), pompom(p) {}

    ///kiir függvény, amely kiírja a foci osztály adattagjait
    void kiir(std::ostream& os);

    ///get függvény, amelynek a kiírásnál fontos szerepe van
    int getPompom() const;

    ///set függvény, amelynek a szerkesztésnél fontos szerepe van.
    void setPompom(int p);

    ///Destruktor
    ~Kosar(){}
};

///Output stream kezelő operátor túlterhelése.
std::ostream& operator<<(std::ostream& os, const Kosar& k);

#endif //NHF___PROG2_KOSAR_H
