#ifndef NHF___PROG2_LISTA_HPP
#define NHF___PROG2_LISTA_HPP

#include "csapat.h"
#include "foci.h"
#include "kosar.h"
#include "kezi.h"
#include "string"
#include "memtrace.h"
#include "fstream"
#include "sstream"
#include "iostream"

///A 'Csapatlista' osztály egy olyan adatszerkezet, amely tárolja a 'Csapat' objektumokat egy láncolt listában.
class CsapatLista{
private:
    struct Tarolo{
        Csapat* adat;
        Tarolo* next;
        Tarolo(Tarolo *cs = nullptr): next(nullptr){};
    };
    Tarolo* elso;
public:
    ///Az 'Iterator' osztály a 'CsapatLista' osztályhoz tartozik
    ///Lehetővé teszi az iterációt a 'CsapatLista' elemein
    ///Az 'Iterator' objektumok segtségével lehet a 'CsapatLista' osztály elemeit bejárni, és hozzáférni az egyes elemekhez.
    class Iterator {
        friend class CsapatLista;
    protected:
        ///A Tarolo* típusú adattag az aktuális elemre mutat a láncolt listában.
        Tarolo* elem;
    public:
        ///Konstruktor
        ///Beállítja az elem adattagot a megadott értékre
        Iterator(Tarolo* t = nullptr): elem(t) {};

        ///Dereferáló operátor, amely visszaadja az aktuális elemhez tarozó 'Csapat' objektumot.
        Csapat& operator*() {return *elem->adat;}

        ///Nyíl operátor, amely a memóriacím hozzáférési operátora.
        ///Visszaadja az aktuális elemre mutató pointer-t.
        Csapat* operator->() {return elem->adat;}

        ///Előre léptető operátora amely az aktuális elemet továbblépteti a láncolt listában, és visszatér az iterátorra mutató referenciával.
        Iterator& operator++() {
            elem = elem->next;
            return *this;
        }

        ///Utólag léptető operátora.
        ///Először létrehoz egy másolatot az aktuális iterátorról, majd az aktuális elemet továbblépteti a láncolt listában.
        /// Végül visszatér a másolattal.
        Iterator operator++(int){
            Iterator tmp = *this;
            ++(*this);
            return tmp;
        }

        ///egyenlőségvizsgáló operátora.
        ///Összehasonlítja két iterátort az aktuális elemük alapján, és visszatér az eredménnyel
        bool operator==(Iterator rhs) {return elem == rhs.elem;}

        ///Egyenlőtlenségvizsgáló operátora.
        ///Összehasonlítja két iterátort az aktuális elemük alapján, és visszatér az eredménnyel
        bool operator!=(Iterator rhs) const{return elem != rhs.elem;}

    };

    ///TESZTELÉS SZEMPONTJÁBÓL!
    CsapatLista& operator=(const CsapatLista& rhs){
        if(&rhs != this) {
            if (rhs.elso == nullptr)
                elso = nullptr;
            else {
                torol();
                elso = new Tarolo;
                elso->adat = new Csapat(*(rhs.elso->adat));

                Tarolo *akt = elso;
                Tarolo *mozgo = rhs.elso->next;
                while (mozgo != nullptr) {
                    akt->next = new Tarolo;
                    akt = akt->next;
                    akt->adat = new Csapat(*(mozgo->adat));
                    mozgo = mozgo->next;
                }
                akt->next = nullptr;
            }
        }
        return *this;
    }

    ///Konstruktor
    CsapatLista(): elso(nullptr) {};

    ///Destruktor
    ~CsapatLista() {torol();}

    ///A függvény célja az összes elem törlése a láncolt listából, valamint a dinamikusan foglalt elemek felszabadítása.
    void torol(){
        Tarolo* elem = elso;
        while(elem != nullptr) {
            Tarolo* tmp = elem;
            elem = elem->next;
            delete tmp->adat;
            delete tmp;
        }
        elso = nullptr;
    }

    ///A 'hozzaad' függvény egy 'Csapat' objektumot ad hozzá a láncolt listához.
    ///Az új elemet létrehozza, majd azt a láncolt lista végéhez fűzi.
    void hozzaad(Csapat* csapat) {
        Tarolo *uj = new Tarolo;
        uj->adat=csapat;
        uj->next= nullptr;
        if(elso == nullptr){
            elso = uj;
        } else {
            Tarolo* vege = elso;
            while (vege->next != nullptr)
                vege=vege->next;
            vege->next = uj;
        }
    };

    ///!!!TESZTELÉSI ÉS DEBUG SZEMPONTOKBÓL VOLT FONTOS!!!
    ///Visszaadja a láncolt lista hosszát.
    int meret() const {
        int szaml = 0;
        Tarolo* elem = elso;
        while (elem != nullptr) {
            szaml++;
            elem = elem->next;
        }
        return szaml;
    }

    ///A függvény törli az adott iterátor által mutatott elemet a láncolt listából.
    void eltavolit(Iterator& It) {
        Tarolo* t = It.elem;
        if (t == nullptr)
            throw "Hibás törlés";

        if (elso == t){
            Tarolo* tmp = elso->next;
            delete elso->adat;
            delete elso;
            elso = tmp;
        } else {
            Tarolo* mozgo = elso;
            while (mozgo != nullptr && mozgo->next != t) {
                mozgo = mozgo->next;
            }
            if (mozgo == nullptr)
                throw "Nincs ilyen elem";

            mozgo->next = t->next;
            delete t->adat;
            delete t;
        }
    }

    ///A begin és end függvények visszaadják az iterátorokat, amelyek az első és az utolsó elemre mutatnak a láncolt listában
    Iterator begin() const {return Iterator(elso);}
    Iterator end() const {return Iterator(nullptr);}
};

#endif //NHF___PROG2_LISTA_HPP
