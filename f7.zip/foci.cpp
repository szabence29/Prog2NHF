#include "foci.h"

///OTPUT STREAM OPERÁTOR DEFINIÁLÁSA
std::ostream& operator<<(std::ostream& os, const Foci& f) {
    return os << (Csapat &) f << "Masodedzo: " << f.getEdzo2();
}

void Foci::kiir(std::ostream &os) {
    os << *this << std::endl;
}

///GET FÜGGVÉNY DEFINIÁLÁSA

std::string Foci::getEdzo2() const {return edzo2;}

///SET FÜGGVÉNY DEFINIÁLÁSA

void Foci::setEdzo2(std::string e) {edzo2 = e;}