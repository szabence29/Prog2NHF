#include "kosar.h"

///OTPUT STREAM OPERÁTOR DEFINIÁLÁSA
std::ostream& operator<<(std::ostream& os, const Kosar& b){
    return os << (Csapat&)b << "Pompom lányok száma: " << b.getPompom();
}

void Kosar::kiir(std::ostream &os) {
    os << *this << std::endl;
}

///GET FÜGGVÉNY DEFINIÁLÁSA

int Kosar::getPompom() const {return pompom;}

///SET FÜGGVÉNY DEFINIÁLÁSA

void Kosar::setPompom(int p) {pompom = p;}