#ifndef NHF___PROG2_FAJLKEZELES_H
#define NHF___PROG2_FAJLKEZELES_H

#include "Lista.hpp"
#include "csapat.h"
#include "kosar.h"
#include "kezi.h"
#include "foci.h"
#include "fstream"
#include "memtrace.h"

///Adatkezelő osztály
///Az osztályban több függvény is van, amely különböző adatmveleteket végeznek a a 'Csapatlista' objektumon.
class Adatok{
    CsapatLista csapatLista;
public:
    Adatok(){};
    void beolvas(const std::string& fajlnev);
    void hozzaadCsapat(Csapat* csapat);
    void torolCsapat();
    void hozzaadCsapatmanualis();
    void szerkesztCsapat();
    void kiir();
    void fajlbakiir(const std::string& fajlnev);
    void csakfocicsapatkiir();
    void csakkezicsapatkiir();
    void csakkosarcsapatkiir();

    ///TESZTELÉS SZEMPONTJÁBÓL
    CsapatLista& getCsapatLista(){
        return csapatLista;
    };
};

#endif //NHF___PROG2_FAJLKEZELES_H
