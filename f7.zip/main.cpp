#include "iostream"
#include "menu.h"
#include "fajlkezeles.h"
#include "gtest_lite.h"

int main() {

        Foci f('F', "Manchester United", 20, "Premier league", "Erik Ten Hag", 3, "Sir Alex Fergusson");


        TEST(foci, sportag){
            EXPECT_EQ('F', f.getSportag()) << "Nem jo a sportag";
        }ENDM

        TEST(foci, nev){
            std::string nev = "Manchester United";
            EXPECT_EQ(nev, f.getCsapatnev()) << "Nem jo a nev";
        }ENDM

        TEST(foci, letszam){
            EXPECT_EQ(20, f.getLetszam()) << "Nem jo a letszam";
        }ENDM

        TEST(foci, liga){
            std::string liga = "Premier league";
            EXPECT_EQ(liga, f.getEdzo()) << "Nem jo a liga";
        }ENDM

        TEST(foci, edzo){
            std::string edzo = "Erik Ten Hag";
            EXPECT_EQ(edzo, f.getLiga()) << "Nem jo az edzo";
        }ENDM

        TEST(foci, helyezes){
            EXPECT_EQ(3, f.getHelyezes()) << "Nem jo a helyezes";
        }ENDM

        TEST(foci, masodedzo){
            std::string masodedzo = "Sir Alex Fergusson";
            EXPECT_EQ(masodedzo, f.getEdzo2())  << "Nem jo a masodedzo";
        }ENDM

        ///Kezicsapat tesztje

        Kosar k('B', "Lakers", 20, "NBA", "Darvin Ham", 1, 10);

        TEST(kezi, sportag){
                EXPECT_EQ('B', k.getSportag()) << "Nem jo a sportag";
            }ENDM

        TEST(kezi, nev){
            std::string nev = "Lakers";
                EXPECT_EQ(nev, k.getCsapatnev()) << "Nem jo a nev";
            }ENDM

        TEST(kezi, letszam){
                EXPECT_EQ(20, k.getLetszam()) << "Nem jo a letszam";
            }ENDM

        TEST(kezi, liga){
            std::string liga = "NBA";
                EXPECT_EQ(liga, k.getEdzo()) << "Nem jo a liga";
            }ENDM

        TEST(kezi, edzo){
            std::string edzo = "Darvin Ham";
                EXPECT_EQ(edzo, k.getLiga()) << "Nem jo az edzo";
            }ENDM

        TEST(kezi, helyezes){
                EXPECT_EQ(1, k.getHelyezes()) << "Nem jo a helyezes";
            }ENDM

        TEST(kezi, tamogatas){
                EXPECT_EQ(10, k.getPompom())  << "Nem jo a pompom letszam";
            }ENDM

        ///Kosarcsapat tesztje

        Kezi b('H', "Veszprém", 20, "NBI", "Momiir Ilic", 2, 50);

        TEST(kezi, sportag){
                EXPECT_EQ('H', b.getSportag()) << "Nem jo a sportag";
            }ENDM

        TEST(kezi, nev){
            std::string nev = "Veszprém";
                EXPECT_EQ(nev, b.getCsapatnev()) << "Nem jo a nev";
            }ENDM

        TEST(kezi, letszam){
                EXPECT_EQ(20, b.getLetszam()) << "Nem jo a letszam";
            }ENDM

        TEST(kezi, liga){
            std::string liga = "NBI";
                EXPECT_EQ(liga, b.getEdzo()) << "Nem jo a liga";
            }ENDM

        TEST(kezi, edzo){
            std::string edzo = "Momiir Ilic";
                EXPECT_EQ(edzo, b.getLiga()) << "Nem jo az edzo";
            }ENDM

        TEST(kezi, helyezes){
                EXPECT_EQ(2, b.getHelyezes()) << "Nem jo a helyezes";
            }ENDM

        TEST(kezi, tamogatas){
                EXPECT_EQ(50, b.getTamogatas())  << "Nem jo a tamogatas";
            }ENDM

    Adatok lista;
    int menupont, fajlmegnyit = 0;
    elvalaszto();
    std::cout <<"Üdvözlöm a csapatok nyilvántartásában! \n"
                "Válasszon az alábbi menü opciók közül: \n";
    alapmenupontok();
    elvalaszto();
    std::cout << "Választott menüpont: ";
    std::cin >> menupont;
    while (menupont != 4){
        switch (menupont){
            case 1:
                try{
                    fajl_megnyit_beolvas(lista);
                } catch (const char* hiba){
                    std::cout << "Hiba: " << hiba << std::endl;
                    return 0;
                }
                menukiir();
                std::cin >> menupont;
                fajlmegnyit++;
                break;
            case 2:
                if (fajlmegnyit == 0){
                    std::cout << "Nem nyitott még meg fájlt.\n";
                    menukiir();
                    std::cin >> menupont;
                    break;
                }
                szerkesztesmenu(lista);
                menukiir();
                std::cin >> menupont;
            case 3:
                if (fajlmegnyit == 0){
                    std::cout << "Nem nyitott még meg fájlt.";
                    menukiir();
                    std::cin >> menupont;
                    break;
                }
                listamenu(lista);
                menukiir();
                std::cin >> menupont;
                break;
            default:
                std::cout << "Hibás menüpontot adott meg, próbálja újra." << std::endl;
                elvalaszto();
                alapmenupontok();
                elvalaszto();
                std::cout << "Választott menüpont: ";
                std::cin >> menupont;
                std::cout << "\n";
                break;
        }
    }
    try {
        fajl_megnyit_kiir(lista);
    } catch (const char* hiba) {
        std::cout << "Hiba: " << hiba << std::endl;
    }
}